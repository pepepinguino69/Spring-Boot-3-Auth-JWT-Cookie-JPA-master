package com.example.security.full.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullSecurityApplication.class, args);
	}
}
