package com.example.security.full.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
