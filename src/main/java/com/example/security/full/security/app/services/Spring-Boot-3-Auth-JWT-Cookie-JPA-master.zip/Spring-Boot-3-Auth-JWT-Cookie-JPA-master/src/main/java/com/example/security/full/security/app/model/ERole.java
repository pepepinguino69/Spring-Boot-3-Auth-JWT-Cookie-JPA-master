package com.example.security.full.security.app.model;

public enum ERole {
  ROLE_USER,

  ROLE_ADMIN
}
