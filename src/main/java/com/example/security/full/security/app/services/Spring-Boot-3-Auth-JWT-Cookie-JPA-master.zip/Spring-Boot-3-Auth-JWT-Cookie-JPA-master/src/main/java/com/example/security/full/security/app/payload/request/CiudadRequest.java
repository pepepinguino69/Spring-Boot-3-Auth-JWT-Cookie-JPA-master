package com.example.security.full.security.app.payload.request;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CiudadRequest {


    private Long paisId;

    private String  nombre;

}

