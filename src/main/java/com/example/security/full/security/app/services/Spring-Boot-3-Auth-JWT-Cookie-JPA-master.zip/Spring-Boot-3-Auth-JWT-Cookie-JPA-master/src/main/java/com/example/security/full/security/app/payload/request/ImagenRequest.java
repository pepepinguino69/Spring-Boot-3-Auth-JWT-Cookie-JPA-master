package com.example.security.full.security.app.payload.request;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ImagenRequest {


    private String nombre;
    private String urlImagen;
    private Long modeloId;

}


