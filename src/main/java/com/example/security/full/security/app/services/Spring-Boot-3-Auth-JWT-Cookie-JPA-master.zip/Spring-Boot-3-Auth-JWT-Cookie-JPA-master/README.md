## Spring Boot 3 + JPA + Auth JWT

### Description

#### Simple implementation of Spring Boot 3 JPA + Auth + JWT with PostgreSQL database.<br />The app also uses Http-Only Cookies to set and authenticate REST API endpoints.

#### Note: Will update the readme soon🫡
