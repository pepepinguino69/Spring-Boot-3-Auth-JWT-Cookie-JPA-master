package com.example.security.full.security.app.payload.request;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CategoriaRequest {


    private String nombre;
    private String descripcion;
    private String urlImagen;

}

