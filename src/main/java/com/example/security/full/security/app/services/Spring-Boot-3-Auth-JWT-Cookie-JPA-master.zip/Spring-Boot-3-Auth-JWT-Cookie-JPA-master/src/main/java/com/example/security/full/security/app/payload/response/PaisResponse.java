package com.example.security.full.security.app.payload.response;

public class PaisResponse {
    Long id;
    String nombre;
}
