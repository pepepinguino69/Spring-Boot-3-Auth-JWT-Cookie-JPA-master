package com.example.security.full.security.app.payload.request;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class PaisRequest {


    private String nombre;

}
